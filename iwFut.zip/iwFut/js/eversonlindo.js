window.addEventListener("DOMContentLoaded", function () {
  let destaques = document.querySelectorAll(".destaque");
  destaques.forEach(function (destaque) {
    destaque.style.fontWeight = "bold";
  });

});

let vitorias = document.querySelectorAll("#vitorias");
let empates = document.querySelectorAll("#empates");
let resultado = document.querySelectorAll("#resultado")

resultado.forEach((posicaoatual, index) => {
  let vitoria = Number(vitorias[index].textContent)
  let empate = Number(empates[index].textContent)
  let calc = vitoria*3 + empate*1
  posicaoatual.textContent = calc

  let current = 0;
  let target = calc;
  let step = Math.ceil(target / 1000); 
  
  // Função de contagem gradual
  let counter = setInterval(() => {
    current += step;
    if (current >= target) {
      current = target;
      clearInterval(counter); 
    }
    posicaoatual.textContent = current; 
  }, 10);
});
